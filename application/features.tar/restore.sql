--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.2
-- Dumped by pg_dump version 9.6.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public."Users" DROP CONSTRAINT "Users_pkey";
ALTER TABLE ONLY public."Swales" DROP CONSTRAINT "Swales_pkey";
ALTER TABLE ONLY public."Points" DROP CONSTRAINT "Points_pkey";
ALTER TABLE ONLY public."Alarm" DROP CONSTRAINT "Alarm_pkey";
ALTER TABLE public."Users" ALTER COLUMN "ID" DROP DEFAULT;
ALTER TABLE public."Swales" ALTER COLUMN "ID" DROP DEFAULT;
ALTER TABLE public."Points" ALTER COLUMN "ID" DROP DEFAULT;
DROP SEQUENCE public."Users_ID_seq";
DROP TABLE public."Users";
DROP SEQUENCE public."Swales_ID_seq";
DROP TABLE public."Swales";
DROP SEQUENCE public."Points_ID_seq";
DROP TABLE public."Points";
DROP TABLE public."Alarm";
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: Alarm; Type: TABLE; Schema: public; Owner: User
--

CREATE TABLE "Alarm" (
    "UserID" integer NOT NULL,
    "Location" point NOT NULL,
    "Time" timestamp without time zone NOT NULL,
    "Need" text,
    "Description" text,
    "UserName" text NOT NULL
);


ALTER TABLE "Alarm" OWNER TO "User";

--
-- Name: Points; Type: TABLE; Schema: public; Owner: User
--

CREATE TABLE "Points" (
    "ID" integer NOT NULL,
    "Name" text NOT NULL,
    "Location" point NOT NULL,
    "Description" text,
    "Type" text NOT NULL,
    "Capacity" text NOT NULL
);


ALTER TABLE "Points" OWNER TO "User";

--
-- Name: Points_ID_seq; Type: SEQUENCE; Schema: public; Owner: User
--

CREATE SEQUENCE "Points_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Points_ID_seq" OWNER TO "User";

--
-- Name: Points_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: User
--

ALTER SEQUENCE "Points_ID_seq" OWNED BY "Points"."ID";


--
-- Name: Swales; Type: TABLE; Schema: public; Owner: User
--

CREATE TABLE "Swales" (
    "ID" integer NOT NULL,
    "Name" text NOT NULL,
    "Location" polygon NOT NULL,
    "Description" text,
    "Capacity" text NOT NULL,
    "Seasonality" text NOT NULL,
    "Grade" text NOT NULL
);


ALTER TABLE "Swales" OWNER TO "User";

--
-- Name: Swales_ID_seq; Type: SEQUENCE; Schema: public; Owner: User
--

CREATE SEQUENCE "Swales_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Swales_ID_seq" OWNER TO "User";

--
-- Name: Swales_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: User
--

ALTER SEQUENCE "Swales_ID_seq" OWNED BY "Swales"."ID";


--
-- Name: Users; Type: TABLE; Schema: public; Owner: User
--

CREATE TABLE "Users" (
    "ID" integer NOT NULL,
    "Name" text NOT NULL,
    "E-mail" text NOT NULL,
    "Password" text NOT NULL,
    "Role" text NOT NULL
);


ALTER TABLE "Users" OWNER TO "User";

--
-- Name: Users_ID_seq; Type: SEQUENCE; Schema: public; Owner: User
--

CREATE SEQUENCE "Users_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Users_ID_seq" OWNER TO "User";

--
-- Name: Users_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: User
--

ALTER SEQUENCE "Users_ID_seq" OWNED BY "Users"."ID";


--
-- Name: Points ID; Type: DEFAULT; Schema: public; Owner: User
--

ALTER TABLE ONLY "Points" ALTER COLUMN "ID" SET DEFAULT nextval('"Points_ID_seq"'::regclass);


--
-- Name: Swales ID; Type: DEFAULT; Schema: public; Owner: User
--

ALTER TABLE ONLY "Swales" ALTER COLUMN "ID" SET DEFAULT nextval('"Swales_ID_seq"'::regclass);


--
-- Name: Users ID; Type: DEFAULT; Schema: public; Owner: User
--

ALTER TABLE ONLY "Users" ALTER COLUMN "ID" SET DEFAULT nextval('"Users_ID_seq"'::regclass);


--
-- Data for Name: Alarm; Type: TABLE DATA; Schema: public; Owner: User
--

COPY "Alarm" ("UserID", "Location", "Time", "Need", "Description", "UserName") FROM stdin;
\.
COPY "Alarm" ("UserID", "Location", "Time", "Need", "Description", "UserName") FROM '$$PATH$$/3073.dat';

--
-- Data for Name: Points; Type: TABLE DATA; Schema: public; Owner: User
--

COPY "Points" ("ID", "Name", "Location", "Description", "Type", "Capacity") FROM stdin;
\.
COPY "Points" ("ID", "Name", "Location", "Description", "Type", "Capacity") FROM '$$PATH$$/3070.dat';

--
-- Name: Points_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: User
--

SELECT pg_catalog.setval('"Points_ID_seq"', 1, false);


--
-- Data for Name: Swales; Type: TABLE DATA; Schema: public; Owner: User
--

COPY "Swales" ("ID", "Name", "Location", "Description", "Capacity", "Seasonality", "Grade") FROM stdin;
\.
COPY "Swales" ("ID", "Name", "Location", "Description", "Capacity", "Seasonality", "Grade") FROM '$$PATH$$/3072.dat';

--
-- Name: Swales_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: User
--

SELECT pg_catalog.setval('"Swales_ID_seq"', 1, false);


--
-- Data for Name: Users; Type: TABLE DATA; Schema: public; Owner: User
--

COPY "Users" ("ID", "Name", "E-mail", "Password", "Role") FROM stdin;
\.
COPY "Users" ("ID", "Name", "E-mail", "Password", "Role") FROM '$$PATH$$/3075.dat';

--
-- Name: Users_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: User
--

SELECT pg_catalog.setval('"Users_ID_seq"', 1, false);


--
-- Name: Alarm Alarm_pkey; Type: CONSTRAINT; Schema: public; Owner: User
--

ALTER TABLE ONLY "Alarm"
    ADD CONSTRAINT "Alarm_pkey" PRIMARY KEY ("UserID");


--
-- Name: Points Points_pkey; Type: CONSTRAINT; Schema: public; Owner: User
--

ALTER TABLE ONLY "Points"
    ADD CONSTRAINT "Points_pkey" PRIMARY KEY ("ID");


--
-- Name: Swales Swales_pkey; Type: CONSTRAINT; Schema: public; Owner: User
--

ALTER TABLE ONLY "Swales"
    ADD CONSTRAINT "Swales_pkey" PRIMARY KEY ("ID");


--
-- Name: Users Users_pkey; Type: CONSTRAINT; Schema: public; Owner: User
--

ALTER TABLE ONLY "Users"
    ADD CONSTRAINT "Users_pkey" PRIMARY KEY ("ID");


--
-- PostgreSQL database dump complete
--

